This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.

Because a proper PHP library for Payvision was not availble, we decided to create one ourself and publish it for everyone to use it.
You're allowed to use this library as long as you don't use it for commercial uses and share the adjustments you make. Please push your changes and I'll review and merge it.

WARNING: We and other contributors are NOT RESPONSIBLE for any consequences when you use this library!!!

Supported operations:
* basicoperations/payment
* basicoperations/refund
* threedsecureoperators/checkenrollment
* threedsecureoperators/paymentusingintegratedmpi