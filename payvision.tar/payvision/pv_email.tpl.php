<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Paimai Live Auction</title>
<style>
body
{
	margin:0px auto;
	padding:0px;
	width:100%;
}
p
{
	line-height:normal;
}
</style>
</head>
<body>
	<?php echo $data['body'];?>
</body>
</html>
