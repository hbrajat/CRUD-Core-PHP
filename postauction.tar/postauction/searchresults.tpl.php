<?php
global $base_url ;
//echo 'Results page' ;
//print_r($search_results);
?>
<table>
      <th colspan="13" bgcolor="#cccccc">Dispute History</th> 
    <tr>
        <th>Name Used</th>
        <th>Lot Count</th>
        <th>Total Amount</th>
        <th>Catalog</th>
        <th>Status </th>
        <th>Time Submitted</th>
        <th>Sale Date</th>
        <th>Reason</th>               
        <th>Auction House</th>       
     
        
    </tr>  
    <?php 
   // print_r($search_results);
    if(!empty($search_results)){
    foreach ($search_results as $res) {
     //   print_r($res);
        //echo 'qqqqqq'.$res->entity_id ;
    if(isset($res->bidder_id)) { 
        $user_dtl = user_load($res->bidder_id); 
    }
	$lot_count = disputed_lot_count($res->auction_id, $res->bidder_id);
	$dispute_status = dispute_current_status($res->auction_id, $res->bidder_id);
	$dispute_amount = disputed_amount($res->auction_id, $res->bidder_id);
	$sale_date = auction_sale_date($res->auction_id, $res->bidder_id);
    
    $seller_dt = user_load($seller_id);
    $dr_id = $res->dispute_reason;
   $dr_load = taxonomy_term_load($dr_id);
    /* elseif (isset($res->entity_id)) { 
        $user_dtl = user_load($res->entity_id);  
    } */
   // print_r($user_dtl);
	//$lot_dtl = node_load($res->lot_id) ; 
	$act_dtl = node_load($res->auction_id) ;  
	$seller_id = $act_dtl->uid;
	//$seller_id = 73;
	$seller_dt = user_load($seller_id);
	$seller_name = $seller_dt->field_first_name['und'][0]['value']." ".$seller_dt->field_last_name['und'][0]['value'];
	//print_r($seller_dt);
      
?>
    
  
        <tr>              
        <td><?php echo $user_dtl->name; ?></td> 
        <td><?php echo $lot_count; ?></td> 
        <td><?php echo $dispute_amount; ?></td> 
        <td><?php echo $act_dtl->title; ?></td> 
         <td><?php echo $dispute_status; ?></td> 
        <td><?php echo $res->dispute_date; ?></td>
        <td><?php echo $sale_date; ?></td>        
        <td><?php echo  $dr_load->name; ?></td>     
        <td><?php echo $seller_name; ?></td>        
     
       
        
    </tr>
   
    <?php }} else { ?>
    <tr>
        <td cosspan="5"><h2>No records found</h2></td>
    </tr>
    <?php } ?>
     <a class="form-submit" href="<?php echo $base_url;?>/dispute/database">Back to search</a>
</table>
