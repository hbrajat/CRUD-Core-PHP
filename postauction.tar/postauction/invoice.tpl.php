<?php
global $base_url;
$term = taxonomy_term_load($node->field_category['und'][0]['tid']);
?>
<table align="center" width="600" border="0" cellspacing="0" cellpadding="0" class="email-table">
    <tr><td><a href="javascript:void();" onclick="window.history.back();">back</a></td></tr>  
  <tr>
      <td align="center" style="background:#ad0303; height:120px; padding:10px 0 10px 0px;"><img src="<?php echo $base_url.'/'.drupal_get_path('theme',$GLOBALS['theme']);?>/images/logo-img.png" width="306" height="109" alt="del sam familie" /></td>
  </tr>
  <tr>
    <td style="background:#dd3a3a; height:40px;"><p style="font-family:Arial, Helvetica, sans-serif; font-size:14px; font-weight:bold; color:#fff; padding:0px 0 0 10px;" > Lor separat existentie es un myth. Por scientie</p></td>
  </tr>
  <tr>
    <td style=" background:#FFF;">
    	<div class="invoice-cont">
        	<div class="invoice-top">
            	<h3>INVOICE #<?php echo INVOICE_PREFIX.$invoice->id;?> </h3>
                <p><?php echo $node->title;?></p>
            </div>
            <div class="invoice-middle">
            	<div class="invoice-left">
                	<h4>Username: <?php echo $bidderUser->name;?></h4>
                    <p><?php echo $bidderUser->mail;?></p>
                    <p><?php echo $bidderUser->field_home_phone['und'][0]['value'];?></p>
                    <p><?php echo $bidderUser->field_address['und'][0]['name'];?></p>
                    <p><?php echo $bidderUser->field_address['und'][0]['street'];?><br/><?php echo $bidderUser->field_address['und'][0]['city'];?><br/><?php echo $bidderUser->field_address['und'][0]['country_name'];?><br/><?php echo $bidderUser->field_address['und'][0]['postal_code'];?></p>
                </div>
                <div class="invoice-right">
                	<h4><?php echo $term->name; ?></h4>
                        <h4>Username: <?php echo $salerUser->name;?></h4>
                    <p><?php echo $salerUser->mail;?></p>
                    <p><?php echo $salerUser->field_home_phone['und'][0]['value'];?></p>
                    <p><?php echo $salerUser->field_address['und'][0]['name'];?></p>
                    <p><?php echo $salerUser->field_address['und'][0]['street'];?><br/><?php echo $salerUser->field_address['und'][0]['city'];?><br/><?php echo $salerUser->field_address['und'][0]['country_name'];?><br/><?php echo $salerUser->field_address['und'][0]['postal_code'];?></p>
                </div>
                <div class="invoice-details">
                	<h4>Invoice Details</h4>
                    <div class="invoice-desc">
                    	<div class="row1">
                        	<label class="first">&nbsp;</label>
                        	<div class="row1-right"><label>Item Total:</label>
                            <span>USD <?php echo $invoice->bid_price;?></span></div>
                        </div>
                        <div class="row1">
                        	<label class="first">&nbsp;</label>
                        	<div class="row1-right"><label>Buyers Premium:</label>
                            <span>USD <?php echo $invoice->premium;?></span></div>	
                        </div>
                        <div class="row1">
                        	<label class="first">&nbsp;</label>
                        	<div class="row1-right"><label>Sub Total:</label>
                            <span>USD <?php echo ($invoice->bid_price+$invoice->premium);?></span></div>	
                        </div>
                        <?php print drupal_render(drupal_get_form('invoice_form',$invoice)); ?> 
                    </div>
                </div>
                <div class="invoice-details">
                	<h4>Payment Details</h4>
                    <div class="pay-detail">
                    	<h4>Method of Payments</h4>
                        <?php echo $node->field_payment_detail['und'][0]['value'];?>
                    </div>
                    
                </div>
               
            	
            </div>
        
        	
        
        
     </div>
    
   	  
    </td>
  </tr>
    <tr>
        <td align="center"><b>Item Details</b></td>
    </tr>
  <tr>
      <td>
          <?php echo lots_table($node->nid,$bidderUser->uid); ?>
      </td>
  
  </tr>
 
  <tr>
    <td style="background:#1d1e22; height:130px;">
    	<p style="font-family:Arial, Helvetica, sans-serif; color:#FFF; font-size:12px; padding:10px 0 0 10px;">Contact:<br /> <span><a href="mailto: info@paimailive.com" style="color:#ae0303; font-family:Arial, Helvetica, sans-serif; font-size:12px; padding:0 0 0 0px;">info@paimailive.com</a></span></p>
    
    <p style="font-family:Arial, Helvetica, sans-serif; color:#FFF; font-size:12px; padding:0 0 0 10px;">Need help?<br /><span><a href="http://www.paimailive.com" style="color:#ae0303; font-family:Arial, Helvetica, sans-serif; font-size:12px; padding:0 0 0 0px;">www.paimailive.com</a></span></p>
    <p style="font-family:Arial, Helvetica, sans-serif; color:#FFF; font-size:12px; padding:10px 0 0 10px;">Bid live using our apps:</p>
    <p style="padding:0 0 0 10px;"><span><a href="#" title="#" target="_blank"><img src="img/icon-a.png" width="25" height="29" alt="#" /></a></span> <a href="#" title="#" target="_blank"><img src="img/icon-aa.png" width="22" height="29" /></a></p>
    </td>
  </tr>
</table>
  
