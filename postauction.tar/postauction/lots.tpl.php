<table>
	<tr>
		<th>Lot #</th>
		<th>Title</th>
                <th>Premium(USD)</th>
		<th>Hammer Price(USD)</th>
		<th>Lot total(USD)</th>
	</tr>
	
	<?php 
	foreach ($data as $value) {		
            $act_dtl = node_load($value->auction_id) ;
            $user_dtl = user_load($value->uid);
            $lot_dtl = node_load($value->lot_id);
        ?>
	<tr>
	<td><?php echo $value->lot_no; ?></td>
        <td><a href="<?php echo url('node/'.$lot_dtl->nid);?>"><?php echo $lot_dtl->title; ?></a></td>
	<td><?php echo $value->premium; ?></td>
	<td><?php echo $value->hammer_price;?></td>
        <td><?php echo $value->hammer_price+$value->premium;?></td>
</tr>
	<?php } ?>
</table>

<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

