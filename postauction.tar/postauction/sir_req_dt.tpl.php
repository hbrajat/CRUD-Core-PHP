<?php
//print_r($data);
$auction_dt = node_load($data->auction_id);
$lot_dt = node_load($data->lot_id);
$seller_dt = user_load($data->seller_id);
$bidder_dt = user_load($data->user_id);
$rr_dt = taxonomy_term_load($data->remove_reason);
?>
<table width="50%" style="width:50%!important;">
	<tr><td width="25%"><strong> Auction </strong> </td><td><?php echo $auction_dt->nid."-".$auction_dt->title?></td></tr>
	<tr><td width="25%"><strong> Lot </strong> </td><td><?php echo $lot_dt->nid."-".$lot_dt->title?></td></tr>
	<tr><td><strong>Sent On</strong> </td><td><?php echo date("Y-m-d",strtotime($data->date))?></td></tr>
	<tr><td><strong>Seller</strong> </td><td><?php echo $seller_dt->mail;?></td></tr>
	<tr><td><strong>Bidder</strong> </td><td><?php echo $bidder_dt->mail;?></td></tr>
	<tr><td><strong>Status</strong> </td><td><?php echo remove_soldlot_request_status($data->status);?></td></tr>
	<tr><td><strong>Reason</strong> </td><td><?php echo $rr_dt->name;?></td></tr>
	<tr><td><strong>Seller Comment</strong> </td><td><?php echo $data->comment;?></td></tr>
	<tr><td><strong>&nbsp;</strong> </td><td><a onclick="history.go(-1);" href="javascript:void(0)"> Back</a>
	</td></tr>
	
</table>
